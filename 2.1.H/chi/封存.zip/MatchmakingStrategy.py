class MatchmakingStrategy:
    def find_match(self, individual, individuals):
        pass

