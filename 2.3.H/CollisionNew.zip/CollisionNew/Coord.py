class Coord:
    def __init__(self, x, sprite=None):
        self.x = x
        self.sprite = sprite

    def set_sprite(self, sprite):
        self.sprite = sprite

