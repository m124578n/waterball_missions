from abc import ABC


class Sprite(ABC):
    def __init__(self):
        self.name = None
