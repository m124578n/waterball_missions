from Sprite import Sprite


class Hero(Sprite):
    def __init__(self):
        super().__init__()
        self.name = "H"
        self.hp = 30

