from Sprite import Sprite


class Water(Sprite):
    def __init__(self):
        super().__init__()
        self.name = "W"
