

class CardTemplate:
    pass

