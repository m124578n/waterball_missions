from ..AIPlayerTemplate import AIPlayerTemplate


class AIPlayer(AIPlayerTemplate):
    def _set_take_turn_rule(self):
        return 0
