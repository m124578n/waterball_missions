from enum import Enum


class Suits(Enum):
    Club = 1
    Diamond = 2
    Heart = 3
    Spade = 4
