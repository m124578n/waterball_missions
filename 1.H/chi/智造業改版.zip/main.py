from abc import ABC, abstractmethod
import random
from enum import Enum


class Card:
    def __init__(self, suit, rank):
        self.suit = suit
        self.rank = rank

    def __str__(self):
        return "{} {}".format(self.suit, self.rank)


class Suits(Enum):
    club = 1
    diamond = 2
    heart = 3
    spade = 4


class Ranks(Enum):
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8
    NINE = 9
    TEN = 10
    JACK = 11
    QUEEN = 12
    KING = 13
    ACE = 14


class Deck:
    def __init__(self):
        self.cards = [Card(suit, rank) for suit in Suits for rank in Ranks]

    def shuffle(self):
        random.shuffle(self.cards)

    def draw(self):
        return self.cards.pop()


class Exchange:
    def __init__(self):
        self.countdown = 3

    def reduce_countdown(self):
        self.countdown -= 1


class Player(ABC):
    def __init__(self):
        self.hands = []
        self.done_exchange_hands_right = False
        self.point = 0
        self.name = ''

    @abstractmethod
    def name_self(self, name):
        pass

    def add_hands_card(self, card):
        self.hands.append(card)

    @abstractmethod
    def do_exchange_hands_right(self, player):
        pass

    def get_point(self):
        self.point += 1


class Human(Player):
    def __init__(self):
        super().__init__()

    def name_self(self, name):
        self.name = name

    def do_exchange_hands_right(self, player):
        temp_hands = self.hands
        self.hands = player.hands
        player.hands = temp_hands

    def show(self, choose):
        return self.hands.pop(choose)

    def show_hand(self):
        return {x + 1: self.hands[x].__str__() for x in range(len(self.hands))}


class AI(Player):
    def __init__(self):
        super().__init__()

    def name_self(self, name):
        self.name = name

    def do_exchange_hands_right(self, player):
        pass

    def show(self):
        return self.hands.pop()


class Game:
    def __init__(self):
        self.deck = Deck()
        self.round = 0
        self.exchange = False
        self.players = []
        self.bot_players = 4

    def start(self):
        real_player = int(input("請輸入有幾個真實玩家："))
        self.bot_players = 4 - real_player
        for i in range(real_player):
            name = input("請輸入你的名字 : ")
            human = Human()
            human.name_self(name)
            self.players.append(human)

        for i in range(self.bot_players):
            ai = AI()
            ai.name_self("ai_bot0" + str(i + 1))
            self.players.append(ai)

        print("洗牌")
        self.deck.shuffle()
        print("發牌")
        for player in self.players:
            for i in range(13):
                player.add_hands_card(self.deck.draw())

        while self.round != 13:
            print("回合開始")
            card_list = []
            for player in self.players:
                print(player.name + "的手牌：")

                if isinstance(player, Human):
                    print(player.show_hand())
                    if not player.done_exchange_hands_right:
                        des = input("請問是否有要跟別人交換牌：y/n")
                        if des == 'y' or des == 'Y':
                            for x in self.players:
                                print(x.name)
                            exchange_name = input("請問要跟誰交換：")

                            while exchange_name not in [x.name for x in self.players]:
                                exchange_name = input('請選擇一個存在的人：')
                                for x in self.players:
                                    print(x.name)
                            target_player = None
                            for p in self.players:
                                if p.name == exchange_name:
                                    target_player = p
                                    break
                            if target_player is not None:
                                player.do_exchange_hands_right(target_player)
                                print('交換成功，只能持續３回合')
                                player.done_exchange_hands_right = True
                                self.exchange = True
                                exchange = Exchange()
                                print(player.show_hand())

                    if self.exchange:
                        print(exchange.countdown)
                        exchange.reduce_countdown()
                        if exchange.countdown == 0:
                            target_player = None
                            for p in self.players:
                                if p.name == exchange_name:
                                    target_player = p
                                    break
                            if target_player is not None:
                                player.do_exchange_hands_right(target_player)
                                print("交換結束，轉換回來")
                                self.exchange = False
                                print(player.show_hand())
                    choose = ''
                    while not isinstance(choose, int) or choose > len(player.hands):
                        try:
                            choose = int(input("請選擇你的牌：（請輸入數字）")) - 1
                            if choose > len(player.hands):
                                print("你沒有那麼多張牌")
                                continue
                        except ValueError:
                            print("請輸入數字")
                            continue
                    card_list.append(player.show(choose))
                else:
                    card_list.append(player.show())
            print("開牌")
            for card in card_list:
                print(card.__str__())
            winner_number = self.compare_cards(card_list)
            self.players[winner_number].get_point()
            print("本回合" + self.players[winner_number].name + "勝利")

            input("按enter鍵往下回合")

            self.round += 1

        winner = self.check_winner()
        print("最終勝利者為：%s" % winner)
        #     print("回合開始")
        #     card_list = []
        #     hand_index = 1
        #     for hand in human.hands:
        #         print(str(hand_index) + " : " + hand.__str__())
        #         hand_index += 1
        #
        #     if not human.done_exchange_hands_right:
        #         des = input("請問是否有要跟別人交換牌：y/n")
        #         if des == 'y' or des == 'Y':
        #             exchange_name = input("請問要跟誰交換：%s, %s ,%s " % (ai_1.name, ai_2.name, ai_3.name))
        #             if exchange_name == "1":
        #                 human.do_exchange_hands_right(ai_1)
        #             elif exchange_name == "2":
        #                 human.do_exchange_hands_right(ai_2)
        #             else:
        #                 human.do_exchange_hands_right(ai_3)
        #             print('交換成功，只能持續３回合')
        #             human.done_exchange_hands_right = True
        #             self.exchange = True
        #             exchange = Exchange()
        #             hand_index = 1
        #             for hand in human.hands:
        #                 print(str(hand_index) + " : " + hand.__str__())
        #                 hand_index += 1
        #
        #     if self.exchange:
        #         print(exchange.countdown)
        #         exchange.reduce_countdown()
        #         if exchange.countdown == 0:
        #             if exchange_name == "1":
        #                 human.do_exchange_hands_right(ai_1)
        #             elif exchange_name == "2":
        #                 human.do_exchange_hands_right(ai_2)
        #             else:
        #                 human.do_exchange_hands_right(ai_3)
        #             print("交換結束，轉換回來")
        #             self.exchange = False
        #             hand_index = 1
        #             for hand in human.hands:
        #                 print(str(hand_index) + " : " + hand.__str__())
        #                 hand_index += 1
        #
        #     choose = ''
        #     while not isinstance(choose, int) or choose > len(human.hands):
        #         try:
        #             choose = int(input("請選擇你的牌：（請輸入數字）"))
        #             if choose > len(human.hands):
        #                 print("你沒有那麼多張牌")
        #                 continue
        #         except ValueError:
        #             print("請輸入數字")
        #             continue
        #
        #     card_list.append(human.show(choose - 1))
        #     card_list.append(ai_1.show())
        #     card_list.append(ai_2.show())
        #     card_list.append(ai_3.show())
        #     print("開牌")
        #     for card in card_list:
        #         print(card.__str__())
        #     winner_number = self.compare_cards(card_list)
        #     if winner_number == 0:
        #         human.get_point()
        #         print("本回合玩家1勝利")
        #     elif winner_number == 1:
        #         ai_1.get_point()
        #         print("本回合玩家2勝利")
        #     elif winner_number == 2:
        #         ai_2.get_point()
        #         print("本回合玩家3勝利")
        #     else:
        #         ai_3.get_point()
        #         print("本回合玩家4勝利")
        #     self.round += 1
        #     input("按enter鍵往下回合")
        #
        # winner = self.check_winner(human, ai_1, ai_2, ai_3)
        # print("最終勝利者為：%s" % winner)

    @staticmethod
    def check_winner(*players):
        winner_point = 0
        winner = ''
        for player in players:
            if player.point > winner_point:
                winner = player
        return winner.name

    @staticmethod
    def compare_cards(card_list):
        winner = 0
        big_card = 0
        for i in range(len(card_list)):
            if big_card == 0:
                big_card = card_list[i]
                winner = i
            if big_card.rank.value < card_list[i].rank.value:
                big_card = card_list[i]
                winner = i
            elif big_card.rank.value == card_list[i].rank.value:
                if big_card.suit.value < card_list[i].suit.value:
                    big_card = card_list[i]
                    winner = i
            else:
                pass
        return winner


if __name__ == "__main__":
    game = Game()
    game.start()
