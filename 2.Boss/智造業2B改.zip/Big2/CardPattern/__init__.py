from .FullHouse import FullHouse
from .Pair import Pair
from .Single import Single
from .Straight import Straight
