from .Player import Player


class AIPlayer(Player):
    def __init__(self, index):
        super().__init__(index)

    def name_himself(self):
        pass

    def take_turn(self):
        pass

    def yell_pass(self):
        pass

    def play(self, player_decide_play):
        pass


