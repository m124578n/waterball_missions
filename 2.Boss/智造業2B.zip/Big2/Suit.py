from enum import Enum


class Suit(Enum):
    C = 1
    D = 2
    H = 3
    S = 4
