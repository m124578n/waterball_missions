from .CardPatternHandler import CardPatternHandler
from ..Card import Card
from ..CardPattern import Straight
from ..SortedCards import SortedCards


class IsStraight(CardPatternHandler, SortedCards):

    def set_cards_amount(self, cards):
        return len(cards) != 5

    def set_check_card_pattern_rule(self, cards):
        self.cards = cards
        self.sort_spec_rule()
        cards = self.cards
        biggest_card = self.cards[0]
        for i in range(len(cards)):
            if biggest_card.rank.value - cards[i].rank.value != i:
                if self.next is not None:
                    return self.next.check(cards)
                else:
                    return False
        return Straight(cards)

    # def check(self, cards: list[Card]):
    #     if len(cards) != 5:
    #         if self.next is not None:
    #             return self.next.check(cards)
    #         else:
    #             return False
    #     self.cards = cards
    #     self.sort_spec_rule()
    #     cards = self.cards
    #     biggest_card = self.cards[0]
    #     for i in range(len(cards)):
    #         if biggest_card.rank.value - cards[i].rank.value != i:
    #             if self.next is not None:
    #                 return self.next.check(cards)
    #             else:
    #                 return False
    #     return Straight(cards)


