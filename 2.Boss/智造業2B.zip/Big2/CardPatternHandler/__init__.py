from .IsPair import IsPair
from .IsFullHouse import IsFullHouse
from .IsSingle import IsSingle
from .IsStraight import IsStraight
