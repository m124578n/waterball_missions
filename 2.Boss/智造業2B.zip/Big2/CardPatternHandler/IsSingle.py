from .CardPatternHandler import CardPatternHandler
from ..Card import Card
from Big2.CardPattern import Single


class IsSingle(CardPatternHandler):

    def set_cards_amount(self, cards):
        return len(cards) != 1

    def set_check_card_pattern_rule(self, cards):
        return Single(cards)

    # def check(self, cards: list[Card]):
    #     if len(cards) != 1:
    #         if self.next is not None:
    #             return self.next.check(cards)
    #         else:
    #             return False
    #     else:
    #         return Single(cards)
